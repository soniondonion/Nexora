execute as @a[tag=nx_a_event_start] at @s run function nexora:alert/event_start/p56
schedule function nexora:alert/event_start/t72 16t
