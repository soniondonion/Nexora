package nexora.mod;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.GameProfileArgument;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import nexora.core.ColorPolicy;
import nexora.core.DeathSystem;
import nexora.core.GulagSystem;
import nexora.core.PlayerRecord;
import nexora.core.PlayerState;
import nexora.core.TeamSystem;

/**
 * Commands.
 *
 *  /nexora ...   ADMIN  — {@code requires} is evaluated on the server, and the server only sends a client the
 *                command nodes whose requirement it passes (vanilla Commands#sendCommands). So non-admins get
 *                no suggestions for it AND every executes() re-checks authorization (defense in depth).
 *  /equipo ...   PLAYER — teams, available to everyone.
 *  /estado       PLAYER — own elimination state only (nothing about anyone else).
 *
 * Syntax is a PROPOSAL (the owner asked not to fix it before checking conventions). UNCOMPILED.
 * VERIFY in-game that non-admins really receive no /nexora suggestions.
 */
@EventBusSubscriber(modid = Nexora.MODID)
public final class NexoraCommands {

    private NexoraCommands() {
    }

    /** Trial results being assembled by an admin before being sealed into the core. */
    private static final class Staging {
        final List<UUID> placement = new ArrayList<>();
        final Set<UUID> completed = new LinkedHashSet<>();
    }

    private static final Map<String, Staging> STAGING = new LinkedHashMap<>();

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(adminRoot());
        d.register(teamRoot());
        d.register(Commands.literal("estado").executes(NexoraCommands::ownState));
    }

    // =================================================================== helpers

    private static boolean admin(CommandSourceStack s) {
        return NexoraPermissions.isAdmin(s);
    }

    private static int denied(CommandSourceStack s) {
        // Deliberately vague: do not confirm that an admin command exists.
        s.sendFailure(Component.literal("Comando desconocido o sin permiso."));
        return 0;
    }

    private static int fail(CommandSourceStack s, String msg) {
        s.sendFailure(Component.literal(msg));
        return 0;
    }

    private static int ok(CommandSourceStack s, String msg) {
        s.sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    private static String nameOf(UUID id) {
        ServerPlayer online = Nexora.server.getPlayerList().getPlayer(id);
        if (online != null) {
            return online.getGameProfile().getName();
        }
        return Nexora.deaths.get(id).map(r -> r.lastName).orElse(id.toString());
    }

    private static boolean notReady(CommandSourceStack s) {
        if (!Nexora.ready()) {
            fail(s, "NEXORA no está disponible: el estado no se pudo cargar. Revisa el log del servidor.");
            return true;
        }
        return false;
    }

    // =================================================================== /nexora (admin)

    private static LiteralArgumentBuilder<CommandSourceStack> adminRoot() {
        return Commands.literal("nexora")
                .requires(NexoraCommands::admin)
                .then(Commands.literal("status").executes(c -> guarded(c, NexoraCommands::status)))
                .then(Commands.literal("panel").executes(c -> guarded(c, ctx -> {
                    Datapack.run(Nexora.server, "execute as " + ctx.getSource().getPlayerOrException().getGameProfile().getName()
                            + " run function nexora:admin/panel");
                    return 1;
                })))
                .then(Commands.literal("reload").executes(c -> guarded(c, ctx -> {
                    try {
                        Nexora.reloadConfig();
                    } catch (IOException | RuntimeException e) {
                        return fail(ctx.getSource(), "Configuración inválida, se mantiene la anterior: " + e.getMessage());
                    }
                    return ok(ctx.getSource(), "Configuración recargada.");
                })))
                .then(Commands.literal("alert")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .executes(c -> guarded(c, ctx -> playAlert(ctx, "@a")))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(c -> guarded(c, ctx -> {
                                            Collection<ServerPlayer> ps = EntityArgument.getPlayers(ctx, "targets");
                                            for (ServerPlayer p : ps) {
                                                Datapack.alert(Nexora.server, StringArgumentType.getString(ctx, "id"),
                                                        "@a[name=" + p.getGameProfile().getName() + "]");
                                            }
                                            return ps.size();
                                        })))))
                .then(Commands.literal("player")
                        .then(Commands.literal("state")
                                .then(Commands.argument("target", GameProfileArgument.gameProfile())
                                        .executes(c -> guarded(c, NexoraCommands::playerState))))
                        .then(Commands.literal("restore")
                                .then(Commands.argument("target", GameProfileArgument.gameProfile())
                                        .executes(c -> guarded(c, NexoraCommands::playerRestore)))))
                .then(Commands.literal("team")
                        .then(Commands.literal("disband")
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .executes(c -> guarded(c, ctx -> {
                                            try {
                                                var o = Nexora.teams.adminDisband(StringArgumentType.getString(ctx, "name"),
                                                        adminName(ctx.getSource()));
                                                if (!o.ok()) {
                                                    return fail(ctx.getSource(), "Equipo no encontrado.");
                                                }
                                                TeamVisuals.syncAll(Nexora.server);
                                                return ok(ctx.getSource(), "Equipo disuelto.");
                                            } catch (IOException e) {
                                                return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
                                            }
                                        })))))
                .then(gulagTree());
    }

    private static LiteralArgumentBuilder<CommandSourceStack> gulagTree() {
        return Commands.literal("gulag")
                .then(Commands.literal("open").executes(c -> guarded(c, ctx -> {
                    try {
                        var o = Nexora.gulag.open(adminName(ctx.getSource()), System.nanoTime());
                        if (!o.ok()) {
                            return fail(ctx.getSource(), "No se puede abrir en el estado actual: " + o.error());
                        }
                        BanSync.reconcile(Nexora.server); // GULAG players must be allowed to log in
                        Datapack.alert(Nexora.server, "gulag_open", "@a");
                        return ok(ctx.getSource(), "Gulag abierto con " + o.value() + " participante(s).");
                    } catch (IOException e) {
                        return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
                    }
                })))
                .then(Commands.literal("close").executes(c -> guarded(c, ctx -> {
                    try {
                        var o = Nexora.gulag.close(adminName(ctx.getSource()));
                        BanSync.reconcile(Nexora.server);
                        return o.ok() ? ok(ctx.getSource(), "Gulag cerrado.") : fail(ctx.getSource(), "Ya estaba cerrado.");
                    } catch (IOException e) {
                        return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
                    }
                })))
                .then(Commands.literal("participants").executes(c -> guarded(c, ctx -> {
                    StringBuilder sb = new StringBuilder("Participantes: ");
                    for (UUID u : Nexora.gulag.participants()) {
                        sb.append(nameOf(u)).append(' ');
                    }
                    return ok(ctx.getSource(), sb.toString().trim());
                })))
                .then(Commands.literal("trial")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .then(Commands.argument("type", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                                java.util.Arrays.stream(GulagSystem.TrialType.values()).map(Enum::name), b))
                                        .executes(c -> guarded(c, NexoraCommands::trialAdd)))))
                .then(Commands.literal("place")
                        .then(Commands.argument("trial", StringArgumentType.word())
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> guarded(c, ctx -> stage(ctx, true)))))) // appends next place
                .then(Commands.literal("complete")
                        .then(Commands.argument("trial", StringArgumentType.word())
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> guarded(c, ctx -> stage(ctx, false))))))
                .then(Commands.literal("seal")
                        .then(Commands.argument("trial", StringArgumentType.word())
                                .executes(c -> guarded(c, NexoraCommands::seal))))
                .then(Commands.literal("returns")
                        .then(Commands.argument("n", IntegerArgumentType.integer(0))
                                .executes(c -> guarded(c, ctx -> {
                                    try {
                                        Nexora.gulag.setReturns(IntegerArgumentType.getInteger(ctx, "n"), adminName(ctx.getSource()));
                                        return ok(ctx.getSource(), "Regresos establecidos.");
                                    } catch (IOException e) {
                                        return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
                                    }
                                }))))
                .then(Commands.literal("standings").executes(c -> guarded(c, ctx -> {
                    int i = 0;
                    for (GulagSystem.Standing s : Nexora.gulag.standings()) {
                        i++;
                        ctx.getSource().sendSuccess(() -> Component.literal(
                                "#" + s.rank() + " " + nameOf(s.player()) + " — " + s.points() + " pts, "
                                        + s.trialsCompleted() + " pruebas"), false);
                    }
                    return i;
                })))
                .then(Commands.literal("results").executes(c -> guarded(c, ctx -> {
                    // Presentation only: tags the top 3 (nx_rank1..3) and plays the "gulag_results" alert,
                    // whose subtitle selectors read those tags. Never changes any player state.
                    Nexora.server.getPlayerList().getPlayers().forEach(p -> {
                        for (int r = 1; r <= 3; r++) {
                            Datapack.run(Nexora.server, "tag " + p.getUUID() + " remove nx_rank" + r);
                        }
                    });
                    int tagged = 0;
                    for (GulagSystem.Standing s : Nexora.gulag.standings()) {
                        if (s.rank() >= 1 && s.rank() <= 3) {
                            Datapack.run(Nexora.server, "tag " + s.player() + " add nx_rank" + s.rank());
                            tagged++;
                        }
                    }
                    Datapack.alert(Nexora.server, "gulag_results", "@a");
                    return ok(ctx.getSource(), "Resultados mostrados (" + tagged + " en el podio).");
                })))
                .then(Commands.literal("finish").executes(c -> guarded(c, ctx -> finish(ctx, Set.of()))))
                .then(Commands.literal("finish")
                        .then(Commands.argument("tiePick", EntityArgument.players())
                                .executes(c -> guarded(c, ctx -> {
                                    Set<UUID> picks = new LinkedHashSet<>();
                                    for (ServerPlayer p : EntityArgument.getPlayers(ctx, "tiePick")) {
                                        picks.add(p.getUUID());
                                    }
                                    return finish(ctx, picks);
                                }))));
    }

    @FunctionalInterface
    private interface Body {
        int run(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException;
    }

    /** Re-checks authorization on EVERY execution (the requires() predicate is not the only guard). */
    private static int guarded(CommandContext<CommandSourceStack> ctx, Body body) throws CommandSyntaxException {
        if (!admin(ctx.getSource())) {
            return denied(ctx.getSource());
        }
        if (notReady(ctx.getSource())) {
            return 0;
        }
        return body.run(ctx);
    }

    private static String adminName(CommandSourceStack s) {
        return s.getEntity() instanceof ServerPlayer p ? p.getGameProfile().getName() : "console";
    }

    private static int status(CommandContext<CommandSourceStack> ctx) {
        return ok(ctx.getSource(), "NEXORA 0.1.0 | equipos=" + Nexora.teams.all().size()
                + " | eliminados=" + Nexora.deaths.inState(PlayerState.ELIMINATED).size()
                + " | gulag=" + Nexora.gulag.status());
    }

    private static int playAlert(CommandContext<CommandSourceStack> ctx, String targets) {
        try {
            Datapack.alert(Nexora.server, StringArgumentType.getString(ctx, "id"), targets);
            return 1;
        } catch (IllegalArgumentException e) {
            return fail(ctx.getSource(), "Id de alerta inválido.");
        }
    }

    private static int playerState(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        int n = 0;
        for (GameProfile gp : GameProfileArgument.getGameProfiles(ctx, "target")) {
            Optional<PlayerRecord> r = Nexora.deaths.get(gp.getId());
            String line = gp.getName() + ": " + (r.map(x -> x.state.name() + " (eliminaciones=" + x.eliminationCount
                    + ", regresos=" + x.revivalCount + ")").orElse("ALIVE (sin registro)"));
            ctx.getSource().sendSuccess(() -> Component.literal(line), false);
            n++;
        }
        return n;
    }

    private static int playerRestore(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        int n = 0;
        for (GameProfile gp : GameProfileArgument.getGameProfiles(ctx, "target")) {
            try {
                DeathSystem.Result r = Nexora.deaths.restore(gp.getId(), adminName(ctx.getSource()));
                String msg = switch (r) {
                    case APPLIED -> "restaurado (se aplicará en el spawn principal)";
                    case ALREADY_IN_STATE -> "ya estaba pendiente de regreso";
                    case REJECTED -> "no se puede restaurar desde su estado actual";
                };
                ctx.getSource().sendSuccess(() -> Component.literal(gp.getName() + ": " + msg), false);
                n += r == DeathSystem.Result.APPLIED ? 1 : 0;
            } catch (IOException e) {
                fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
            }
        }
        BanSync.reconcile(Nexora.server);
        NexoraEvents.applyPendingReturns(Nexora.server);
        return n;
    }

    private static int trialAdd(CommandContext<CommandSourceStack> ctx) {
        try {
            GulagSystem.TrialType type = GulagSystem.TrialType.valueOf(StringArgumentType.getString(ctx, "type").toUpperCase());
            var o = Nexora.gulag.addTrial(StringArgumentType.getString(ctx, "id"), type);
            return o.ok() ? ok(ctx.getSource(), "Prueba añadida.") : fail(ctx.getSource(), "No se puede añadir: " + o.error());
        } catch (IllegalArgumentException e) {
            return fail(ctx.getSource(), "Tipo de prueba inválido.");
        } catch (IOException e) {
            return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
        }
    }

    private static int stage(CommandContext<CommandSourceStack> ctx, boolean placed) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
        Staging st = STAGING.computeIfAbsent(StringArgumentType.getString(ctx, "trial"), k -> new Staging());
        if (placed) {
            if (st.placement.contains(p.getUUID())) {
                return fail(ctx.getSource(), "Ya tiene puesto en esta prueba.");
            }
            st.placement.add(p.getUUID());
        } else {
            st.completed.add(p.getUUID());
        }
        return ok(ctx.getSource(), "Registrado (sin confirmar hasta 'seal'). Puestos: " + st.placement.size());
    }

    private static int seal(CommandContext<CommandSourceStack> ctx) {
        String trial = StringArgumentType.getString(ctx, "trial");
        Staging st = STAGING.getOrDefault(trial, new Staging());
        try {
            var o = Nexora.gulag.recordResult(trial, st.placement, st.completed);
            if (!o.ok()) {
                return fail(ctx.getSource(), "No se pudo registrar: " + o.error());
            }
            STAGING.remove(trial);
            return ok(ctx.getSource(), "Resultado de la prueba registrado.");
        } catch (IOException e) {
            return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
        }
    }

    private static int finish(CommandContext<CommandSourceStack> ctx, Set<UUID> picks) {
        try {
            var o = Nexora.gulag.finish(adminName(ctx.getSource()), picks);
            if (!o.ok()) {
                if (o.error() == GulagSystem.Error.TIE_UNRESOLVED) {
                    StringBuilder sb = new StringBuilder("Empate en el corte. Elige con '/nexora gulag finish <jugadores>' entre: ");
                    o.value().unresolvedTie().forEach(u -> sb.append(nameOf(u)).append(' '));
                    return fail(ctx.getSource(), sb.toString().trim());
                }
                return fail(ctx.getSource(), "No se puede finalizar: " + o.error());
            }
            BanSync.reconcile(Nexora.server);
            NexoraEvents.applyPendingReturns(Nexora.server);
            return ok(ctx.getSource(), "Gulag finalizado. Regresan " + o.value().returned().size() + " jugador(es).");
        } catch (IOException e) {
            return fail(ctx.getSource(), "Error al guardar: " + e.getMessage());
        }
    }

    // =================================================================== /estado

    private static int ownState(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        if (notReady(ctx.getSource())) {
            return 0;
        }
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        return ok(ctx.getSource(), "Tu estado: " + Nexora.deaths.stateOf(p.getUUID()).name());
    }

    // =================================================================== /equipo (players)

    private static LiteralArgumentBuilder<CommandSourceStack> teamRoot() {
        return Commands.literal("equipo")
                .then(Commands.literal("crear")
                        .then(Commands.argument("nombre", StringArgumentType.word())
                                .then(Commands.argument("color", StringArgumentType.word())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(allowedColors(), b))
                                        .executes(c -> team(c, ctx -> {
                                            var o = Nexora.teams.create(ctx.getSource().getPlayerOrException().getUUID(),
                                                    StringArgumentType.getString(ctx, "nombre"),
                                                    StringArgumentType.getString(ctx, "color"));
                                            return report(ctx, o, "Equipo creado. Eres el líder.");
                                        })))))
                .then(Commands.literal("color")
                        .then(Commands.argument("color", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(allowedColors(), b))
                                .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.changeColor(
                                        ctx.getSource().getPlayerOrException().getUUID(),
                                        StringArgumentType.getString(ctx, "color")), "Color cambiado.")))))
                .then(Commands.literal("solicitar")
                        .then(Commands.argument("equipo", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                        Nexora.teams.all().stream().map(t -> t.name), b))
                                .executes(c -> team(c, NexoraCommands::requestJoin))))
                .then(Commands.literal("aceptar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.accept(
                                        ctx.getSource().getPlayerOrException().getUUID(),
                                        EntityArgument.getPlayer(ctx, "jugador").getUUID()), "Solicitud aceptada.")))))
                .then(Commands.literal("rechazar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.reject(
                                        ctx.getSource().getPlayerOrException().getUUID(),
                                        EntityArgument.getPlayer(ctx, "jugador").getUUID()), "Solicitud rechazada.")))))
                .then(Commands.literal("solicitudes").executes(c -> team(c, NexoraCommands::listRequests)))
                .then(Commands.literal("expulsar")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.kick(
                                        ctx.getSource().getPlayerOrException().getUUID(),
                                        EntityArgument.getPlayer(ctx, "jugador").getUUID()), "Integrante expulsado.")))))
                .then(Commands.literal("abandonar")
                        .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.leave(
                                ctx.getSource().getPlayerOrException().getUUID()), "Has abandonado el equipo."))))
                .then(Commands.literal("lider")
                        .then(Commands.argument("jugador", EntityArgument.player())
                                .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.transferLeadership(
                                        ctx.getSource().getPlayerOrException().getUUID(),
                                        EntityArgument.getPlayer(ctx, "jugador").getUUID()), "Liderazgo transferido.")))))
                .then(Commands.literal("disolver")
                        .executes(c -> team(c, ctx -> report(ctx, Nexora.teams.disband(
                                ctx.getSource().getPlayerOrException().getUUID()), "Equipo disuelto."))))
                .then(Commands.literal("info").executes(c -> team(c, NexoraCommands::teamInfo)))
                .then(Commands.literal("miembros").executes(c -> team(c, NexoraCommands::teamInfo)))
                .then(Commands.literal("lista").executes(c -> team(c, ctx -> {
                    // Public listing: team name, color and member COUNT only. No UUIDs, no coordinates.
                    for (TeamSystem.Team t : Nexora.teams.all()) {
                        ctx.getSource().sendSuccess(() -> Component.literal(
                                t.name + " (" + t.color + ") — " + t.members.size() + " integrante(s)"), false);
                    }
                    return Nexora.teams.all().size();
                })));
    }

    private static List<String> allowedColors() {
        ColorPolicy cp = new ColorPolicy(Nexora.config == null ? new nexora.core.NexoraConfig().teamForbiddenColors
                : Nexora.config.teamForbiddenColors);
        List<String> out = new ArrayList<>();
        for (String c : ColorPolicy.namedColors()) {
            if (cp.validate(c).isPresent()) {
                out.add(c);
            }
        }
        return out;
    }

    @FunctionalInterface
    private interface TeamBody {
        int run(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException, IOException;
    }

    private static int team(CommandContext<CommandSourceStack> ctx, TeamBody body) throws CommandSyntaxException {
        if (notReady(ctx.getSource())) {
            return 0;
        }
        try {
            return body.run(ctx);
        } catch (IOException e) {
            Nexora.LOGGER.error("[NEXORA] team persistence failed", e);
            return fail(ctx.getSource(), "No se pudo guardar el cambio.");
        }
    }

    private static <T> int report(CommandContext<CommandSourceStack> ctx, TeamSystem.Outcome<T> o, String success) {
        if (o.ok()) {
            TeamVisuals.syncAll(Nexora.server);
            return ok(ctx.getSource(), success);
        }
        return fail(ctx.getSource(), describe(o.error()));
    }

    private static String describe(TeamSystem.Error e) {
        return switch (e) {
            case NAME_INVALID -> "Nombre inválido: usa letras, números o _ (sin espacios) y respeta la longitud permitida.";
            case NAME_TAKEN -> "Ya existe un equipo con ese nombre.";
            case COLOR_INVALID -> "Color inválido.";
            case COLOR_FORBIDDEN -> "Ese color está reservado y no se puede usar.";
            case ALREADY_IN_TEAM -> "Ya perteneces a un equipo.";
            case NOT_IN_TEAM -> "No perteneces a ningún equipo.";
            case NO_SUCH_TEAM -> "Ese equipo no existe.";
            case NOT_LEADER -> "Solo el líder puede hacer eso.";
            case NO_SUCH_REQUEST -> "No hay una solicitud vigente de ese jugador.";
            case DUPLICATE_REQUEST -> "Ya enviaste una solicitud a ese equipo.";
            case TEAM_FULL -> "El equipo está completo.";
            case LEADER_CANNOT_LEAVE -> "El líder no puede abandonar: transfiere el liderazgo o disuelve el equipo.";
            case NOT_A_MEMBER -> "Ese jugador no es integrante del equipo.";
            case SELF_TARGET -> "No puedes hacerlo contigo mismo.";
            case REQUEST_EXPIRED -> "La solicitud expiró.";
        };
    }

    private static int requestJoin(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException, IOException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        var o = Nexora.teams.requestJoin(p.getUUID(), StringArgumentType.getString(ctx, "equipo"));
        if (!o.ok()) {
            return fail(ctx.getSource(), describe(o.error()));
        }
        // Notify the leader (if online) with clickable accept / reject.
        ServerPlayer leader = Nexora.server.getPlayerList().getPlayer(o.value().leader);
        if (leader != null) {
            String n = p.getGameProfile().getName();
            MutableComponent msg = Component.literal(n + " quiere unirse a tu equipo. ").withStyle(ChatFormatting.GREEN)
                    .append(Component.literal("[Aceptar] ").withStyle(s -> s.withColor(ChatFormatting.GREEN)
                            .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/equipo aceptar " + n))))
                    .append(Component.literal("[Rechazar]").withStyle(s -> s.withColor(ChatFormatting.GRAY)
                            .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/equipo rechazar " + n))));
            leader.sendSystemMessage(msg);
        }
        return ok(ctx.getSource(), "Solicitud enviada.");
    }

    private static int listRequests(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        var o = Nexora.teams.pendingRequests(ctx.getSource().getPlayerOrException().getUUID());
        if (!o.ok()) {
            return fail(ctx.getSource(), describe(o.error()));
        }
        if (o.value().isEmpty()) {
            return ok(ctx.getSource(), "No hay solicitudes pendientes.");
        }
        for (UUID u : o.value()) {
            ctx.getSource().sendSuccess(() -> Component.literal("- " + nameOf(u)), false);
        }
        return o.value().size();
    }

    private static int teamInfo(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        var t = Nexora.teams.teamOfPlayer(ctx.getSource().getPlayerOrException().getUUID());
        if (t.isEmpty()) {
            return fail(ctx.getSource(), describe(TeamSystem.Error.NOT_IN_TEAM));
        }
        TeamSystem.Team team = t.get();
        ctx.getSource().sendSuccess(() -> Component.literal(team.name + " (" + team.color + ")"), false);
        for (UUID m : team.members) {
            String tag = m.equals(team.leader) ? " [líder]" : "";
            ctx.getSource().sendSuccess(() -> Component.literal("- " + nameOf(m) + tag), false);
        }
        return team.members.size();
    }
}
