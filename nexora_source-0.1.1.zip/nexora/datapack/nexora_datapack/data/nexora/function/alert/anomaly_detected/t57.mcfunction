execute as @a[tag=nx_a_anomaly_detected] at @s run function nexora:alert/anomaly_detected/p57
schedule function nexora:alert/anomaly_detected/t60 3t
