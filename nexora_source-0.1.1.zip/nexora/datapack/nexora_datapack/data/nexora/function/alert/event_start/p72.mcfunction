title @s times 8 50 20
title @s subtitle {"storage":"nexora:config","nbt":"alerts.event_start.subtitle","color":"#8a8f8c"}
title @s title {"storage":"nexora:config","nbt":"alerts.event_start.title","color":"#39ff88","bold":true}
