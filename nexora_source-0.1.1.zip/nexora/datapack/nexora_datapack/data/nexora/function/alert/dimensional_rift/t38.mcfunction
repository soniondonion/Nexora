execute as @a[tag=nx_a_dimensional_rift] at @s run function nexora:alert/dimensional_rift/p38
schedule function nexora:alert/dimensional_rift/t40 2t
