scoreboard players remove system_error nexora.rep 1
schedule function nexora:alert/system_error/t0 20t
