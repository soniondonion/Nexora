package nexora.mod;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.server.permission.PermissionAPI;
import net.neoforged.neoforge.server.permission.events.PermissionGatherEvent;
import net.neoforged.neoforge.server.permission.nodes.PermissionNode;
import net.neoforged.neoforge.server.permission.nodes.PermissionTypes;

/**
 * Single source of truth for "is this an administrator".
 *
 * VERIFY (uncompiled): PermissionNode constructor and PermissionGatherEvent.Nodes#addNodes signatures
 * were taken from the NeoForge javadocs for 1.21.x; confirm against the exact NeoForge version used.
 */
@EventBusSubscriber(modid = Nexora.MODID)
public final class NexoraPermissions {

    public static final String ADMIN_TAG = "nexora_admin";

    /** Default resolver: vanilla OP level >= configured minimum. A permissions mod can override the node. */
    public static final PermissionNode<Boolean> ADMIN = new PermissionNode<>(
            Nexora.MODID, "admin", PermissionTypes.BOOLEAN,
            (player, uuid, context) -> player != null
                    && Nexora.config != null
                    && player.hasPermissions(Nexora.config.adminMinOpLevel));

    private NexoraPermissions() {
    }

    @SubscribeEvent
    public static void onGather(PermissionGatherEvent.Nodes event) {
        event.addNodes(ADMIN);
    }

    /** Authorization AND authentication. Fails closed when the mod state is not ready. */
    public static boolean isAdmin(ServerPlayer player) {
        if (!Nexora.ready() || player == null) {
            return false;
        }
        try {
            boolean authorized = PermissionAPI.getPermission(player, ADMIN);
            boolean authenticated = Nexora.auth.isAuthenticated(player)
                    || (Nexora.config.allowAdminsWithoutAuthInOfflineMode && !Nexora.server.usesAuthentication());
            return authorized && authenticated;
        } catch (RuntimeException e) {
            Nexora.LOGGER.error("[NEXORA] permission check failed, denying", e);
            return false;
        }
    }

    /** Console and command blocks count as trusted server sources; players must pass isAdmin. */
    public static boolean isAdmin(CommandSourceStack source) {
        if (source.getEntity() == null) {
            return source.hasPermission(2);
        }
        return source.getEntity() instanceof ServerPlayer p && isAdmin(p);
    }
}
