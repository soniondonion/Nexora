execute as @a[tag=nx_a_location_found] at @s run function nexora:alert/location_found/p34
schedule function nexora:alert/location_found/t36 2t
