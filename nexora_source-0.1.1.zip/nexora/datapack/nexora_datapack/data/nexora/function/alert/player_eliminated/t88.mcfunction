execute as @a[tag=nx_a_player_eliminated] at @s run function nexora:alert/player_eliminated/p88
schedule function nexora:alert/player_eliminated/t90 2t
