execute as @a[tag=nx_a_system_error] at @s run function nexora:alert/system_error/p22
schedule function nexora:alert/system_error/t24 2t
