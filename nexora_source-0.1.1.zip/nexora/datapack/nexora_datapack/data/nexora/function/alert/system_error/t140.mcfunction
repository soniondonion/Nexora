function nexora:alert/system_error/end
