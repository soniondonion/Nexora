execute as @a[tag=nx_a_system_error] at @s run function nexora:alert/system_error/p28
schedule function nexora:alert/system_error/t30 2t
