scoreboard players set #r nexora.tmp 0
execute if score player_eliminated nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/player_eliminated/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_player_eliminated] remove nx_a_player_eliminated
