execute if score location_found nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-1.6 ^0.32 ^3 0 0 0 0 1 force @s
execute if score location_found nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-1.6 ^0.64 ^3 0 0 0 0 1 force @s
