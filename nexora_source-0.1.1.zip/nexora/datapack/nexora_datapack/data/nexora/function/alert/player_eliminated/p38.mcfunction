execute if score player_eliminated nexora.snd matches 1 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 0.7
