execute if entity @s[type=player,tag=!nexora_admin] run return fail
tellraw @s {"text":"═══ Drops (completa x y z) ═══","color":"green","bold":true}
tellraw @s [{"text":"[Supply]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/preset/supply {id:\"d1\",x:0,y:64,z:0,dim:\"minecraft:overworld\",nbt:'{Items:[]}'}"}}]
tellraw @s [{"text":"[Rare]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/preset/rare {id:\"d1\",x:0,y:64,z:0,dim:\"minecraft:overworld\",nbt:'{Items:[]}'}"}}]
tellraw @s [{"text":"[Nexora]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/preset/nexora {id:\"d1\",x:0,y:64,z:0,dim:\"minecraft:overworld\",nbt:'{Items:[]}'}"}}]
tellraw @s [{"text":"[Emergency]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/preset/emergency {id:\"d1\",x:0,y:64,z:0,dim:\"minecraft:overworld\",nbt:'{Items:[]}'}"}}]
tellraw @s [{"text":"[Mystery]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/preset/mystery {id:\"d1\",x:0,y:64,z:0,dim:\"minecraft:overworld\",nbt:'{Items:[]}'}"}}]
tellraw @s [{"text":"[Eliminar]","color":"red","clickEvent":{"action":"suggest_command","value":"/function nexora:drop/remove {id:\"d1\"}"}}]
tellraw @s [{"text":"[← Panel]","color":"gray","clickEvent":{"action":"run_command","value":"/function nexora:admin/panel"}}]
