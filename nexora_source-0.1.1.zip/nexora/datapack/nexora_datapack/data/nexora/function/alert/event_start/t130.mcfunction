function nexora:alert/event_start/end
