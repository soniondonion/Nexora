scoreboard players set #r nexora.tmp 0
execute if score gulag_results nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/gulag_results/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_gulag_results] remove nx_a_gulag_results
