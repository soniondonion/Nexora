scoreboard players remove player_eliminated nexora.rep 1
schedule function nexora:alert/player_eliminated/t0 20t
