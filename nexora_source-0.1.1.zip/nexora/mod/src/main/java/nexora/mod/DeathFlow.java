package nexora.mod;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import nexora.core.AuditLog;
import nexora.core.DeathSystem;
import nexora.core.NexoraConstants;
import nexora.core.PlayerState;

/**
 * Death sequence:
 *  1. LivingDeathEvent: register the elimination (persisted BEFORE anything else) and sync the ban list.
 *     The inventory is not touched, so vanilla drops it in the world.
 *  2. Presentation: custom message as title, the untouched vanilla death message as subtitle, and the
 *     datapack function nexora:internal/death_sequence for particles/sound (the clock fragmenting).
 *     No chat message is added by NEXORA.
 *  3. Kick after cfg.deathKickDelayTicks.
 *
 * ASSUMPTION TO VERIFY IN-GAME: on a hardcore server the player sits on the death screen until they press
 * "Spectate World". The presentation therefore starts when the respawn event fires; if the player never
 * presses it, they are kicked after GRACE_TICKS anyway (they are already recorded as eliminated).
 */
public final class DeathFlow {

    private static final int GRACE_TICKS = 600; // 30 s

    private static final class Flow {
        final long createdTick;
        final Component vanillaDeathMessage;
        long kickAtTick = -1;

        Flow(long createdTick, Component vanillaDeathMessage) {
            this.createdTick = createdTick;
            this.vanillaDeathMessage = vanillaDeathMessage;
        }
    }

    private static final Map<UUID, Flow> FLOWS = new ConcurrentHashMap<>();

    private DeathFlow() {
    }

    public static void onDeath(ServerPlayer player, DamageSource source) {
        if (!Nexora.ready()) {
            return;
        }
        if (Nexora.config.adminsExemptFromElimination && NexoraPermissions.isAdmin(player)) {
            return; // admins are staff, not participants
        }
        if (!Nexora.deaths.stateOf(player.getUUID()).isPlayable()) {
            // ELIMINATED: no duplicate registration or announcement.
            // GULAG: dying inside a trial (e.g. controlled combat) is part of the competition and must
            // not kick or ban the player; the standings decide who returns.
            return;
        }
        String cause = source.getMsgId();
        try {
            DeathSystem.Result r = Nexora.deaths.eliminate(player.getUUID(), player.getGameProfile().getName(), cause);
            if (r != DeathSystem.Result.APPLIED) {
                return;
            }
        } catch (IOException e) {
            // Persisting failed. Keep going so the player is still removed, and shout about it.
            Nexora.LOGGER.error("[NEXORA] COULD NOT PERSIST ELIMINATION OF {}", player.getUUID(), e);
        }
        BanSync.reconcile(player.server);
        Component vanilla = source.getLocalizedDeathMessage(player);
        FLOWS.put(player.getUUID(), new Flow(player.server.getTickCount(), vanilla));
    }

    /** Called when the (dead) player respawns as spectator, i.e. when they can actually see the HUD. */
    public static void onRespawn(ServerPlayer player) {
        Flow f = FLOWS.get(player.getUUID());
        if (f == null || f.kickAtTick >= 0) {
            return;
        }
        MinecraftServer server = player.server;
        f.kickAtTick = server.getTickCount() + Nexora.config.deathKickDelayTicks;
        // Title: canon message, unchanged. Subtitle: vanilla death message, unchanged.
        player.connection.send(new ClientboundSetTitlesAnimationPacket(10, Math.max(20, Nexora.config.deathKickDelayTicks - 30), 20));
        player.connection.send(new ClientboundSetSubtitleTextPacket(f.vanillaDeathMessage));
        player.connection.send(new ClientboundSetTitleTextPacket(Component.literal(NexoraConstants.DEATH_MESSAGE)));
        Datapack.run(server, "execute as " + player.getGameProfile().getName()
                + " at @s run function nexora:internal/death_sequence");
        Nexora.audit.log(AuditLog.Stream.AUTOMATIC, "death_presentation",
                Map.of("uuid", player.getUUID().toString()));
    }

    public static void tick(MinecraftServer server) {
        if (FLOWS.isEmpty()) {
            return;
        }
        long now = server.getTickCount();
        Iterator<Map.Entry<UUID, Flow>> it = FLOWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Flow> e = it.next();
            Flow f = e.getValue();
            boolean due = f.kickAtTick >= 0 ? now >= f.kickAtTick : now >= f.createdTick + GRACE_TICKS;
            if (!due) {
                continue;
            }
            ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
            if (p != null && Nexora.deaths.stateOf(e.getKey()) == PlayerState.ELIMINATED) {
                p.connection.disconnect(Component.literal(NexoraConstants.DEATH_MESSAGE));
            }
            it.remove();
        }
    }

    public static void forget(UUID id) {
        FLOWS.remove(id);
    }
}
