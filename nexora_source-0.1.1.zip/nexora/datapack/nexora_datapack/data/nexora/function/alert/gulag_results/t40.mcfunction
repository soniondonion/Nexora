execute as @a[tag=nx_a_gulag_results] at @s run function nexora:alert/gulag_results/p40
schedule function nexora:alert/gulag_results/t42 2t
