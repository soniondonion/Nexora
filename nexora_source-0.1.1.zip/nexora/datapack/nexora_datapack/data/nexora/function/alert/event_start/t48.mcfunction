execute as @a[tag=nx_a_event_start] at @s run function nexora:alert/event_start/p48
schedule function nexora:alert/event_start/t50 2t
