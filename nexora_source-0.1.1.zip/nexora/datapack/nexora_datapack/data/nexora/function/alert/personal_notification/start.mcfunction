# NEXORA ALERT #19 Notificación personal (definition v1.0.0)
# Do not edit: generated from alerts/definitions/19_personal_notification.json.
scoreboard players operation personal_notification nexora.rep = personal_notification nexora.repcfg
function nexora:alert/personal_notification/t0
