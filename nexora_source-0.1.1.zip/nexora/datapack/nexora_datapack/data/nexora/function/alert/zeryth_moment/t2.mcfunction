execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p2
schedule function nexora:alert/zeryth_moment/t4 2t
