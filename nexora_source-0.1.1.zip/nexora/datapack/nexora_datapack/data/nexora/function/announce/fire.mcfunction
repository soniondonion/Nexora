$data modify storage nexora:config alerts.$(alert).title set value "$(title)"
$data modify storage nexora:config alerts.$(alert).subtitle set value "$(subtitle)"
$data modify storage nexora:config alerts.$(alert).chat set value "$(chat)"
$scoreboard players set $(alert) nexora.snd $(sound)
$function nexora:alert/play {id:"$(alert)",targets:"$(targets)"}
