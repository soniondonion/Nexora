title @s times 4 32 4
title @s subtitle {"storage":"nexora:config","nbt":"alerts.gulag_results.p1_sub","color":"#8a8f8c"}
title @s title [{"text":""},{"storage":"nexora:config","nbt":"alerts.gulag_results.p1_label","bold":true,"color":"#ffc83a"},{"text":" ","bold":true},{"selector":"@a[tag=nx_rank1,limit=1]","bold":true,"color":"#ffffff"}]
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.277 ^0.115 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.212 ^0.212 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.115 ^0.277 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0 ^0.3 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.115 ^0.277 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.212 ^0.212 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.277 ^0.115 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.277 ^-0.115 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.212 ^-0.212 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^-0.115 ^-0.277 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0 ^-0.3 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.115 ^-0.277 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.212 ^-0.212 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.784f,0.227f],scale:1.3f} ^0.277 ^-0.115 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.snd matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.8
execute if score gulag_results nexora.snd matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 0.9
