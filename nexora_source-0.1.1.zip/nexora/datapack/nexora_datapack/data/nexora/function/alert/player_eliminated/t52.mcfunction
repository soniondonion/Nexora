execute as @a[tag=nx_a_player_eliminated] at @s run function nexora:alert/player_eliminated/p52
schedule function nexora:alert/player_eliminated/t54 2t
