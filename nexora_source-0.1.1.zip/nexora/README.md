# NEXORA — sistemas para la serie hardcore de 21 días

Minecraft Java **1.21.1** · NeoForge 21.1.x · Java 21 · datapack `pack_format 48`.

> **Estado honesto (léelo primero).** Esto es una **primera entrega verificada solo en parte**.
> - ✅ Verificado automáticamente: el núcleo lógico en Java (43 pruebas, con pruebas de mutación) y la coherencia estática del datapack (linter propio).
> - ⚠️ **No verificado:** nada de lo que requiere ejecutar Minecraft. El mod de NeoForge **no se ha compilado** (el entorno de trabajo no pudo descargar NeoForge) y el datapack **no se ha cargado en un juego real**.
> - Nada debe usarse en el servidor de producción antes de completar `docs/TESTING.md` (lista de pruebas en juego).
> Detalle completo: `docs/TESTING.md` y `docs/KNOWN_LIMITATIONS.md`.

## Qué incluye

| Módulo | Dónde | Estado |
|---|---|---|
| CORE (config, JSON atómico, auditoría) | `core/` | Compilado y probado |
| DEATH SYSTEM (estados, persistencia por UUID, mensaje canónico) | `core/` + `mod/` | Lógica probada; integración con NeoForge **sin compilar** |
| GULAG (10 tipos de prueba, puntuación configurable, clasificación, desempates) | `core/` + `mod/` | Lógica probada; puntuaciones **provisionales** |
| TEAMS (sociales, color validado, tarjeta roja solo admins) | `core/` + `mod/` | Lógica probada; visuales **sin probar** |
| ALERT (20 animaciones definidas por JSON) | `alerts/`, datapack | Generadas y lintadas; **sin ver en juego** |
| DIFFICULTY (52 modificaciones) | `difficulty/`, datapack | 31 implementadas, 3 parciales, 15 requieren mod, 3 sin mecánica viable (ver `docs/DIFFICULTY.md`) |
| MOMENTS (19, ciclo de 8 pasos) | `moments/`, datapack | Marco listo; **contenido pendiente** (no se inventó narrativa) |
| Minijuegos (24) | `minigames/`, datapack | Motor listo; **arenas pendientes** |
| Drops (5 categorías) | datapack | Implementados; sin probar |
| Anuncios | datapack | Implementados; **textos por escribir (tuyos)** |
| Panel de administración | datapack (chat) + comandos del mod | Sin probar |
| ARCHIVOS / registro histórico | `core/` (JSONL) + almacenamiento del datapack | Núcleo probado; puente web **no incluido** |

## Estructura

```
core/        Java puro (sin Minecraft): lógica + pruebas (CoreTests)
mod/         Adaptador NeoForge (SIN COMPILAR)
alerts/      Definiciones JSON de las 20 animaciones (ver alerts/README.md)
difficulty/  manifest.json de las 52 modificaciones
moments/     catalog.json (19)      minigames/  catalog.json (24)
tools/       Generadores, linter y build.sh
datapack/    Datapack GENERADO (no editar a mano)
dist/        Versiones empaquetadas (nunca se sobrescriben)
docs/        Documentación
```

## Reconstruir

```bash
tools/build.sh --no-zip   # uso diario: prueba el núcleo, genera + lintea el datapack, regenera docs
# Para una versión nueva: sube VERSION en tools/build_datapack.py y ejecuta tools/build.sh
# (el build se niega a sobrescribir un zip ya existente en dist/)
```

`dist/nexora_datapack-0.1.0.zip` está **obsoleto** (no tiene el filtro de administrador en las funciones de dificultad). Usa `0.1.1`.

## Documentación

`docs/INSTALL.md` · `docs/ADMIN_GUIDE.md` · `docs/COMMANDS.md` · `docs/CONFIG.md` · `docs/ARCHITECTURE.md` · `docs/TESTING.md` · `docs/KNOWN_LIMITATIONS.md` · `docs/DIFFICULTY.md` · `docs/ALERTS.md` · `docs/MOMENTS_AND_MINIGAMES.md` · `docs/RESEARCH.md` · `docs/EXPANSION.md` · `CHANGELOG.md`

## Lo que NO se hizo (a propósito)

Nada se publicó, no se tocó ningún servidor, no se compró nada y no se borró ningún archivo. Los textos oficiales (títulos de alertas, anuncios, narrativa de momentos) **no se inventaron**: todos los textos de alertas son `[PROVISIONAL]`. El mensaje canónico de muerte («El reloj se ha detenido, tu rastro se ha perdido.») está fijado en código y no es configurable.
