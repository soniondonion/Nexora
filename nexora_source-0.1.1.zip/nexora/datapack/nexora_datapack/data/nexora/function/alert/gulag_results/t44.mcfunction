execute as @a[tag=nx_a_gulag_results] at @s run function nexora:alert/gulag_results/p44
schedule function nexora:alert/gulag_results/t46 2t
