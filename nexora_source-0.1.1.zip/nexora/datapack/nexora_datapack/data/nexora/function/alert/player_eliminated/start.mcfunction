# NEXORA ALERT #9 Eliminación de jugador (definition v1.0.0)
# Do not edit: generated from alerts/definitions/09_player_eliminated.json.
scoreboard players operation player_eliminated nexora.rep = player_eliminated nexora.repcfg
function nexora:alert/player_eliminated/t0
