package nexora.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import nexora.core.ColorPolicy;
import nexora.core.TeamSystem;

/**
 * Nametag + TAB presentation using VANILLA scoreboard teams, so no client mod is required.
 *
 * Design (this is what makes the red admin card coexist with a hermandad tag):
 *  - A player can be in only ONE vanilla scoreboard team. So presentation teams are generated per
 *    combination: "nx" + team-id for members and "nxa" + team-id for admins of that hermandad
 *    ("nxa00000000" for admins with no hermandad). The admin variant adds the red card to the prefix.
 *  - Only teams whose name starts with "nx" are ever created, changed or removed here. A player that
 *    already sits in a foreign scoreboard team (another mod or datapack) is skipped and reported, which
 *    avoids fighting other mods over TAB/nametags.
 *  - Friendly-invisible visibility is switched off so these social teams give NO gameplay advantage.
 *
 * Players cannot change vanilla teams (/team needs permission level 2), so the card cannot be forged.
 *
 * VERIFY (uncompiled): Scoreboard/PlayerTeam method names for 1.21.1 (mojmap). If a conflicting mod
 * rewrites the TAB list through packets, the vanilla-team approach will not show there.
 */
public final class TeamVisuals {

    private static final String PREFIX = "nx";
    private static final String CARD = "■ "; // ■ — configurable symbol, red, bold

    private TeamVisuals() {
    }

    public static void syncAll(MinecraftServer server) {
        if (!Nexora.ready()) {
            return;
        }
        Scoreboard sb = server.getScoreboard();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            syncPlayer(server, sb, p);
        }
        removeEmptyTeams(sb);
    }

    public static void syncPlayer(MinecraftServer server, ServerPlayer p) {
        syncPlayer(server, server.getScoreboard(), p);
    }

    private static void syncPlayer(MinecraftServer server, Scoreboard sb, ServerPlayer p) {
        boolean admin = NexoraPermissions.isAdmin(p);
        // keep the datapack-visible tag in step with the real decision (datapack admin functions check it)
        if (admin && !p.getTags().contains(NexoraPermissions.ADMIN_TAG)) {
            p.addTag(NexoraPermissions.ADMIN_TAG);
        } else if (!admin && p.getTags().contains(NexoraPermissions.ADMIN_TAG)) {
            p.removeTag(NexoraPermissions.ADMIN_TAG);
        }

        Optional<TeamSystem.Team> team = Nexora.teams.teamOfPlayer(p.getUUID());
        PlayerTeam current = sb.getPlayersTeam(p.getScoreboardName());
        if (current != null && !current.getName().startsWith(PREFIX)) {
            Nexora.LOGGER.warn("[NEXORA] {} is in foreign scoreboard team '{}': presentation skipped",
                    p.getScoreboardName(), current.getName());
            return;
        }
        if (team.isEmpty() && !admin) {
            if (current != null) {
                sb.removePlayerFromTeam(p.getScoreboardName(), current);
            }
            return;
        }

        String teamName = (admin ? PREFIX + "a" : PREFIX)
                + (team.isPresent() ? shortId(team.get().id) : "00000000");
        PlayerTeam pt = sb.getPlayerTeam(teamName);
        if (pt == null) {
            pt = sb.addPlayerTeam(teamName);
        }
        configure(pt, team.orElse(null), admin);
        if (current == null || !current.getName().equals(teamName)) {
            if (current != null) {
                sb.removePlayerFromTeam(p.getScoreboardName(), current);
            }
            sb.addPlayerToTeam(p.getScoreboardName(), pt);
        }
    }

    private static void configure(PlayerTeam pt, TeamSystem.Team team, boolean admin) {
        MutableComponent prefix = Component.empty();
        if (admin) {
            prefix.append(Component.literal(CARD).withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        }
        ChatFormatting nameColor = ChatFormatting.WHITE;
        if (team != null) {
            ColorPolicy cp = new ColorPolicy(Nexora.config.teamForbiddenColors);
            var valid = cp.validate(team.color);
            int rgb = valid.map(ColorPolicy.Valid::rgb).orElse(0xFFFFFF);
            String named = valid.isPresent() && !team.color.startsWith("#") ? team.color : cp.nearestNamed(rgb);
            ChatFormatting f = ChatFormatting.getByName(named);
            nameColor = f != null ? f : ChatFormatting.WHITE;
            prefix.append(Component.literal("[" + team.name + "] ")
                    .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb))));
        }
        pt.setPlayerPrefix(prefix);
        pt.setColor(nameColor);
        pt.setAllowFriendlyFire(true);
        pt.setSeeFriendlyInvisibles(false);
    }

    private static void removeEmptyTeams(Scoreboard sb) {
        List<PlayerTeam> toRemove = new ArrayList<>();
        for (PlayerTeam t : sb.getPlayerTeams()) {
            if (t.getName().startsWith(PREFIX) && t.getPlayers().isEmpty()) {
                toRemove.add(t);
            }
        }
        toRemove.forEach(sb::removePlayerTeam);
    }

    private static String shortId(UUID id) {
        return String.format("%08x", (int) (id.getMostSignificantBits() >>> 32));
    }
}
