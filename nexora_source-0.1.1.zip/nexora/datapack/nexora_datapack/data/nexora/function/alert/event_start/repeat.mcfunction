scoreboard players remove event_start nexora.rep 1
schedule function nexora:alert/event_start/t0 20t
