# Macro: id, type (contaminated|restricted|claimed), x,y,z (ints), r (int), dim (e.g. minecraft:overworld).
execute if entity @s[type=player,tag=!nexora_admin] run return fail
$data modify storage nexora:zones list append value {id:"$(id)",type:"$(type)",x:$(x),y:$(y),z:$(z),r:$(r),dim:"$(dim)"}
tellraw @a[tag=nexora_admin] [{"text":"[NEXORA] ","color":"green"},{"text":"Zona añadida.","color":"gray"}]
