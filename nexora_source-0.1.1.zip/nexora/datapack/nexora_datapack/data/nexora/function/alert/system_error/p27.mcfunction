execute if score system_error nexora.snd matches 1 run playsound minecraft:block.piston.contract master @s ~ ~ ~ 0.8 0.7
