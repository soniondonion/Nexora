title @s times 5 55 15
title @s subtitle {"storage":"nexora:config","nbt":"alerts.location_found.subtitle","color":"#8a8f8c"}
title @s title {"storage":"nexora:config","nbt":"alerts.location_found.title","color":"#39ff88","bold":true}
