execute as @a[tag=nx_a_dimensional_rift] at @s run function nexora:alert/dimensional_rift/p6
schedule function nexora:alert/dimensional_rift/t8 2t
