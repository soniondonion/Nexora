scoreboard players set #r nexora.tmp 0
execute if score system_error nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/system_error/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_system_error] remove nx_a_system_error
