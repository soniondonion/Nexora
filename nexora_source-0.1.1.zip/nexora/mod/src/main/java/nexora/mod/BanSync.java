package nexora.mod;

import java.util.Optional;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import nexora.core.NexoraConstants;
import nexora.core.PlayerRecord;
import nexora.core.PlayerState;

/**
 * Keeps the vanilla ban list in step with the elimination registry.
 *
 * Why the ban list: it is consulted BEFORE a player joins (PlayerList#canPlayerLogin), it survives
 * restarts, and it works with any login mod. Entries created here carry source "NEXORA"; only those
 * are ever removed by this class, so real administrator bans are never touched.
 *
 * Defense in depth: {@link NexoraEvents} also re-checks the state on login in case an admin pardons
 * a player by hand.
 *
 * VERIFY (uncompiled): UserBanListEntry constructor, StoredUserList#add/remove/get and
 * MinecraftServer#getProfileCache signatures for 1.21.1.
 */
public final class BanSync {

    private BanSync() {
    }

    public static void reconcile(MinecraftServer server) {
        if (!Nexora.ready()) {
            return;
        }
        UserBanList bans = server.getPlayerList().getBans();
        for (PlayerRecord r : Nexora.deaths.all()) {
            Optional<GameProfile> profile = resolve(server, r.uuid, r.lastName);
            if (profile.isEmpty()) {
                Nexora.LOGGER.warn("[NEXORA] cannot resolve profile for {} ({}), ban not synced", r.lastName, r.uuid);
                continue;
            }
            UserBanListEntry existing = bans.get(profile.get());
            boolean ours = existing != null && NexoraConstants.BAN_SOURCE.equals(existing.getSource());
            boolean shouldBeBanned = r.state == PlayerState.ELIMINATED;
            if (shouldBeBanned && existing == null) {
                bans.add(new UserBanListEntry(profile.get(), null, NexoraConstants.BAN_SOURCE, null,
                        NexoraConstants.BAN_REASON_PREFIX + NexoraConstants.DEATH_MESSAGE));
            } else if (!shouldBeBanned && ours) {
                bans.remove(profile.get());
            }
        }
    }

    private static Optional<GameProfile> resolve(MinecraftServer server, UUID id, String name) {
        var online = server.getPlayerList().getPlayer(id);
        if (online != null) {
            return Optional.of(online.getGameProfile());
        }
        Optional<GameProfile> cached = server.getProfileCache() == null
                ? Optional.empty() : server.getProfileCache().get(id);
        if (cached.isPresent()) {
            return cached;
        }
        return name == null ? Optional.empty() : Optional.of(new GameProfile(id, name));
    }
}
