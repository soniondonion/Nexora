function nexora:alert/personal_notification/end
