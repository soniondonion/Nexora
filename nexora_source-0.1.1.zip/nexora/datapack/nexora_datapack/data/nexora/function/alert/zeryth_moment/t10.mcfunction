execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p10
schedule function nexora:alert/zeryth_moment/t12 2t
