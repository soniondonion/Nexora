scoreboard players remove dimensional_rift nexora.rep 1
schedule function nexora:alert/dimensional_rift/t0 20t
