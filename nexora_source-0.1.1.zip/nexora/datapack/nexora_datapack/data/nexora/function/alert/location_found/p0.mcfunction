execute if score location_found nexora.snd matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 0.8
