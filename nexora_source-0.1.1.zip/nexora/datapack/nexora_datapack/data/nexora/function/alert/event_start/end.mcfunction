scoreboard players set #r nexora.tmp 0
execute if score event_start nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/event_start/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_event_start] remove nx_a_event_start
