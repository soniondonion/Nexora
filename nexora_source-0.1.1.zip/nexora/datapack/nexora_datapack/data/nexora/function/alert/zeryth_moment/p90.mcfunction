title @s times 0 5 0
title @s title {"text":"◇","color":"#39ff88","bold":true}
title @s subtitle {"text":" "}
