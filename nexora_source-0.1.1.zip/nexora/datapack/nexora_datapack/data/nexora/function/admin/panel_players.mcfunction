execute if entity @s[type=player,tag=!nexora_admin] run return fail
tellraw @s {"text":"═══ Jugadores · Gulag · Equipos (comandos del mod) ═══","color":"green","bold":true}
tellraw @s [{"text":"[Estado de un jugador]","color":"green","clickEvent":{"action":"suggest_command","value":"/nexora player state "}}]
tellraw @s [{"text":"[Restaurar jugador]","color":"green","clickEvent":{"action":"suggest_command","value":"/nexora player restore "}}]
tellraw @s [{"text":"[Abrir Gulag]","color":"green","clickEvent":{"action":"run_command","value":"/nexora gulag open"}},{"text":" "},{"text":"[Clasificación]","color":"yellow","clickEvent":{"action":"run_command","value":"/nexora gulag standings"}},{"text":" "},{"text":"[Finalizar]","color":"gold","clickEvent":{"action":"run_command","value":"/nexora gulag finish"}},{"text":" "},{"text":"[Cerrar]","color":"red","clickEvent":{"action":"run_command","value":"/nexora gulag close"}}]
tellraw @s [{"text":"[Regresos]","color":"green","clickEvent":{"action":"suggest_command","value":"/nexora gulag returns "}}]
tellraw @s [{"text":"[Disolver equipo]","color":"red","clickEvent":{"action":"suggest_command","value":"/nexora team disband "}}]
tellraw @s [{"text":"[← Panel]","color":"gray","clickEvent":{"action":"run_command","value":"/function nexora:admin/panel"}}]
