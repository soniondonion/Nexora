# NEXORA ALERT #2 Anomalía detectada (definition v1.0.0)
# Do not edit: generated from alerts/definitions/02_anomaly_detected.json.
scoreboard players operation anomaly_detected nexora.rep = anomaly_detected nexora.repcfg
function nexora:alert/anomaly_detected/t0
