# NEXORA ALERT #14 Momento ZERYTH (definition v1.0.0)
# Do not edit: generated from alerts/definitions/14_zeryth_moment.json.
scoreboard players operation zeryth_moment nexora.rep = zeryth_moment nexora.repcfg
function nexora:alert/zeryth_moment/t0
