# NEXORA ALERT #3 Inicio de evento (definition v1.0.0)
# Do not edit: generated from alerts/definitions/03_event_start.json.
scoreboard players operation event_start nexora.rep = event_start nexora.repcfg
function nexora:alert/event_start/t0
