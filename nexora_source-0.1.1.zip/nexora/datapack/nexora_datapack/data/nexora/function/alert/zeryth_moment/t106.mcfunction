execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p106
schedule function nexora:alert/zeryth_moment/t160 54t
