function nexora:alert/anomaly_detected/end
