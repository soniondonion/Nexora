execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.621 ^-0.81 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.832 ^0.228 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.999 ^0.808 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.64 ^-0.846 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-2.148 ^-1.557 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-2.245 ^-0.348 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^0.809 ^1.267 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.832 ^-1.254 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-1.768 ^0.445 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.376 ^0.954 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.704 ^-0.791 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.434 ^0.285 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.snd matches 1 run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
