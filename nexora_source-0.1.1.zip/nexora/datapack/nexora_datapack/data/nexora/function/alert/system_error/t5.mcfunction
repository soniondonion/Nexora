execute as @a[tag=nx_a_system_error] at @s run function nexora:alert/system_error/p5
schedule function nexora:alert/system_error/t6 1t
