function nexora:alert/gulag_results/end
