scoreboard players set #r nexora.tmp 0
execute if score location_found nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/location_found/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_location_found] remove nx_a_location_found
