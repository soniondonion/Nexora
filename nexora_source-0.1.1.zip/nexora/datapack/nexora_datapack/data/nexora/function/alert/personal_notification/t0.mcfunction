execute as @a[tag=nx_a_personal_notification] at @s run function nexora:alert/personal_notification/p0
schedule function nexora:alert/personal_notification/t2 2t
