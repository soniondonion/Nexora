execute as @a[tag=nx_a_gulag_results] at @s run function nexora:alert/gulag_results/p48
schedule function nexora:alert/gulag_results/t80 32t
