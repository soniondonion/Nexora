data modify storage nexora:tmp aq set from storage nexora:announce queue
data modify storage nexora:announce queue set value []
execute store result score #now nexora.tmp run time query gametime
function nexora:announce/loop
