execute if score personal_notification nexora.int matches 2.. anchored eyes run particle minecraft:end_rod ^1.4 ^0.9 ^2.5 0 0 0 0 1 force @s
