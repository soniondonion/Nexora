package nexora.mod;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;

/** Runs datapack functions as the server (never as a player), without echoing output to chat. */
public final class Datapack {

    private Datapack() {
    }

    public static void run(MinecraftServer server, String command) {
        CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, command);
    }

    /** Runs a command as/at a player, addressed by UUID (never by a free-text name). */
    public static void runAs(MinecraftServer server, java.util.UUID player, String command) {
        run(server, "execute as " + player + " at @s run " + command);
    }

    /** Tells the datapack that the companion mod is present (minigames need it for death protection). */
    public static void announceMod(MinecraftServer server) {
        run(server, "scoreboard players set #mod nexora.cfg 1"); // harmless no-op failure if the datapack is absent
    }

    /** Plays an alert (defined in the datapack) for the given selector, e.g. "@a" or "@s". */
    public static void alert(MinecraftServer server, String alertId, String targets) {
        if (!alertId.matches("[a-z0-9_]{1,40}") || !targets.matches("[@A-Za-z0-9_\\[\\]=,!.\\-]{1,80}")) {
            throw new IllegalArgumentException("unsafe alert arguments");
        }
        run(server, "function nexora:alert/play {id:\"" + alertId + "\",targets:\"" + targets + "\"}");
    }
}
