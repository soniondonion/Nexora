execute as @a[tag=nx_a_gulag_results] at @s run function nexora:alert/gulag_results/p122
schedule function nexora:alert/gulag_results/t124 2t
