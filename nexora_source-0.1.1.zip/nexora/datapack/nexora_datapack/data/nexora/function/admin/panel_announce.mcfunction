execute if entity @s[type=player,tag=!nexora_admin] run return fail
tellraw @s {"text":"═══ Anuncios ═══","color":"green","bold":true}
tellraw @s [{"text":"[Enviar ahora]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:announce/send {alert:\"global_alert\",title:\"\",subtitle:\"\",chat:\"\",sound:1,targets:\"@a\"}"}}]
tellraw @s [{"text":"[Programar]","color":"green","clickEvent":{"action":"suggest_command","value":"/function nexora:announce/schedule {alert:\"global_alert\",title:\"\",subtitle:\"\",chat:\"\",sound:1,targets:\"@a\",delay:1200}"}}]
tellraw @s [{"text":"[← Panel]","color":"gray","clickEvent":{"action":"run_command","value":"/function nexora:admin/panel"}}]
