execute if score anomaly_detected nexora.snd matches 1 run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 1.4
execute if score anomaly_detected nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:2.0f} ^0 ^0 ^3 0.3 0.3 0.1 0 12 force @s
title @s times 5 55 15
title @s subtitle {"storage":"nexora:config","nbt":"alerts.anomaly_detected.subtitle","color":"#8a8f8c"}
title @s title [{"text":""},{"text":"◈ ","color":"#39ff88","bold":true},{"storage":"nexora:config","nbt":"alerts.anomaly_detected.title","color":"#39ff88","bold":true}]
