execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.37 ^-1.236 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.654 ^-0.593 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.069 ^-1.554 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.306 ^-0.848 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.689 ^-0.084 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^2.922 ^1.586 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.557 ^-0.048 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.919 ^-0.942 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^2.37 ^-1.491 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.618 ^0.869 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-1.293 ^1.024 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.36 ^-0.881 ^3 0 0 0 0 1 force @s
title @s times 0 5 0
title @s subtitle {"text":" "}
title @s title [{"text":""},{"text":"","color":"#39ff88","bold":true,"obfuscated":false},{"storage":"nexora:config","nbt":"alerts.system_error.title","color":"#39ff88","bold":true,"obfuscated":false}]
