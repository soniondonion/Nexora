scoreboard players remove personal_notification nexora.rep 1
schedule function nexora:alert/personal_notification/t0 20t
