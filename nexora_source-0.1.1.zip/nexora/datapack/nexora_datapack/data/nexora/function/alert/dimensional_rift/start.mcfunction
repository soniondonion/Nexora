# NEXORA ALERT #15 Brecha dimensional (definition v1.0.0)
# Do not edit: generated from alerts/definitions/15_dimensional_rift.json.
scoreboard players operation dimensional_rift nexora.rep = dimensional_rift nexora.repcfg
function nexora:alert/dimensional_rift/t0
