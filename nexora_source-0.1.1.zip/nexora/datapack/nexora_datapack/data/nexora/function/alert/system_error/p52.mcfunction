execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.534 ^0.42 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.343 ^0.501 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.29 ^-1.414 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-2.363 ^1.06 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.366 ^-0.003 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.855 ^0.336 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-2.139 ^-0.12 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.013 ^-0.901 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.193 ^-0.438 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.486 ^1.264 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.48 ^-0.459 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-2.008 ^0.144 ^3 0 0 0 0 1 force @s
title @s times 0 45 15
title @s subtitle {"storage":"nexora:config","nbt":"alerts.system_error.subtitle","color":"#8a8f8c"}
title @s title {"storage":"nexora:config","nbt":"alerts.system_error.title","color":"#ff3b3b","bold":true}
