scoreboard players remove gulag_results nexora.rep 1
schedule function nexora:alert/gulag_results/t0 20t
