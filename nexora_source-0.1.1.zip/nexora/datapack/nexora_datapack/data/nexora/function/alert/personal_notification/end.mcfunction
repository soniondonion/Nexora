scoreboard players set #r nexora.tmp 0
execute if score personal_notification nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/personal_notification/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_personal_notification] remove nx_a_personal_notification
