# Macro: id, value (0|1).
execute if entity @s[type=player,tag=!nexora_admin] run return fail
$scoreboard players set $(id) nexora.snd $(value)
