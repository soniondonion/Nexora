execute if score location_found nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.32 ^-1.6 ^3 0 0 0 0 1 force @s
execute if score location_found nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0 ^-1.6 ^3 0 0 0 0 1 force @s
