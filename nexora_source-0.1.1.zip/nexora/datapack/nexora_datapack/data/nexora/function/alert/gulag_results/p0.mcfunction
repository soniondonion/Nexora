title @s times 5 32 3
title @s subtitle {"storage":"nexora:config","nbt":"alerts.gulag_results.subtitle","color":"#8a8f8c"}
title @s title {"storage":"nexora:config","nbt":"alerts.gulag_results.title","color":"#39ff88","bold":true}
