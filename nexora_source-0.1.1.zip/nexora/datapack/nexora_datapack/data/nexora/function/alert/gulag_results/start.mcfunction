# NEXORA ALERT #12 Resultados del Gulag (definition v1.0.0)
# Do not edit: generated from alerts/definitions/12_gulag_results.json.
scoreboard players operation gulag_results nexora.rep = gulag_results nexora.repcfg
function nexora:alert/gulag_results/t0
