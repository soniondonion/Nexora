execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.519 ^1.361 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.68 ^-0.349 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-1.942 ^-0.004 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-0.504 ^-0.399 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^0.938 ^-0.434 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.096 ^-0.428 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.67 ^-1.517 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.605 ^-0.217 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-2.479 ^0.656 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-3.104 ^-0.933 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-1.429 ^1.478 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.525 ^0.42 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.snd matches 1 run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.9 0.7
title @s times 0 5 0
title @s subtitle {"text":" "}
title @s title [{"text":""},{"text":"    ","color":"#ff3b3b","bold":true,"obfuscated":false},{"storage":"nexora:config","nbt":"alerts.system_error.title","color":"#ff3b3b","bold":true,"obfuscated":false}]
