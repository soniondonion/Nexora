scoreboard players remove anomaly_detected nexora.rep 1
schedule function nexora:alert/anomaly_detected/t0 20t
