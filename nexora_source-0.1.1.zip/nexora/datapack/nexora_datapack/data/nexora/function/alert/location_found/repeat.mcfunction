scoreboard players remove location_found nexora.rep 1
schedule function nexora:alert/location_found/t0 20t
