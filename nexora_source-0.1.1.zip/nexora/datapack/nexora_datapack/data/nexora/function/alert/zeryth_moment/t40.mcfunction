execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p40
schedule function nexora:alert/zeryth_moment/t42 2t
