function nexora:alert/zeryth_moment/end
