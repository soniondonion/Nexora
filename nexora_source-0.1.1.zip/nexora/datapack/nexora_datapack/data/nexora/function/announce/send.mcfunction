# Announcements are independent of animations: pick an alert, give it your own content.
# Macro: alert, title, subtitle, chat ("" = none), sound (0|1), targets (selector). Plain text only (no double quotes).
execute if entity @s[type=player,tag=!nexora_admin] run return fail
$data modify storage nexora:tmp alert set value "$(alert)"
execute if data storage nexora:tmp {alert:"player_eliminated"} run return run tellraw @a[tag=nexora_admin] [{"text":"[NEXORA] ","color":"green"},{"text":"La alerta de eliminación es canónica y no admite anuncios.","color":"red"}]
$data modify storage nexora:config alerts.$(alert).title set value "$(title)"
$data modify storage nexora:config alerts.$(alert).subtitle set value "$(subtitle)"
$data modify storage nexora:config alerts.$(alert).chat set value "$(chat)"
$scoreboard players set $(alert) nexora.snd $(sound)
$function nexora:alert/play {id:"$(alert)",targets:"$(targets)"}
$function nexora:internal/log_event {type:"announcement",id:"$(alert)"}
