execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.26 ^0.15 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.15 ^0.26 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0 ^0.3 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.15 ^0.26 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.26 ^0.15 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.26 ^-0.15 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.15 ^-0.26 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0 ^-0.3 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.15 ^-0.26 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.26 ^-0.15 ^3 0 0 0 0 1 force @s
execute if score event_start nexora.snd matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.7 0.8
