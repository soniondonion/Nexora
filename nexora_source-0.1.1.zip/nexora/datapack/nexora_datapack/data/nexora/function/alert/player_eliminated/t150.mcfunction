function nexora:alert/player_eliminated/end
