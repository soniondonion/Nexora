# Automatic activation: same macro as announce/send plus delay (ticks).
execute if entity @s[type=player,tag=!nexora_admin] run return fail
execute store result score #now nexora.tmp run time query gametime
$scoreboard players add #now nexora.tmp $(delay)
$data modify storage nexora:announce queue append value {alert:"$(alert)",title:"$(title)",subtitle:"$(subtitle)",chat:"$(chat)",sound:$(sound),targets:"$(targets)",due:0}
execute store result storage nexora:announce queue[-1].due int 1 run scoreboard players get #now nexora.tmp
