execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^2.6 ^0 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^2.524 ^0.622 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^2.302 ^1.208 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^1.946 ^1.724 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^1.477 ^2.14 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^0.922 ^2.431 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^0.313 ^2.581 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-0.313 ^2.581 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-0.922 ^2.431 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-1.477 ^2.14 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-1.946 ^1.724 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-2.302 ^1.208 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-2.524 ^0.622 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-2.6 ^0 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-2.524 ^-0.622 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-2.302 ^-1.208 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-1.946 ^-1.724 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-1.477 ^-2.14 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-0.922 ^-2.431 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^-0.313 ^-2.581 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^0.313 ^-2.581 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^0.922 ^-2.431 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^1.477 ^-2.14 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^1.946 ^-1.724 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^2.302 ^-1.208 ^3 0 0 0 0 1 force @s
execute if score dimensional_rift nexora.int matches 1.. anchored eyes run particle minecraft:reverse_portal ^2.524 ^-0.622 ^3 0 0 0 0 1 force @s
title @s times 6 50 18
title @s subtitle {"storage":"nexora:config","nbt":"alerts.dimensional_rift.subtitle","color":"#8a8f8c"}
title @s title {"storage":"nexora:config","nbt":"alerts.dimensional_rift.title","color":"#9b6bff","bold":true}
