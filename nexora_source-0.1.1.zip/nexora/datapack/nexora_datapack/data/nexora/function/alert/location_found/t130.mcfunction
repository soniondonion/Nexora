function nexora:alert/location_found/end
