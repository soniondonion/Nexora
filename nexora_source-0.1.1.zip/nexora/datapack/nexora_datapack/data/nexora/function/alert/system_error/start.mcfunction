# NEXORA ALERT #20 Error del sistema (definition v1.0.0)
# Do not edit: generated from alerts/definitions/20_system_error.json.
scoreboard players operation system_error nexora.rep = system_error nexora.repcfg
function nexora:alert/system_error/t0
