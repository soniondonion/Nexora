execute as @a[tag=nx_a_system_error] at @s run function nexora:alert/system_error/p30
schedule function nexora:alert/system_error/t32 2t
