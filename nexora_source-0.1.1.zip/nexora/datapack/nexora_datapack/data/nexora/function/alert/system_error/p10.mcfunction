execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^0.131 ^0.472 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^2.546 ^0.512 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-1.246 ^-1.163 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-1.682 ^-1.005 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.58 ^0.27 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^1.237 ^-0.266 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^0.145 ^0.874 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^2.326 ^-0.805 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.2f} ^-0.458 ^-0.023 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^-0.735 ^0.893 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^1.212 ^0.556 ^3 0 0 0 0 1 force @s
execute if score system_error nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[1f,0.231f,0.231f],scale:1.2f} ^2.231 ^0.975 ^3 0 0 0 0 1 force @s
title @s times 0 5 0
title @s subtitle {"text":" "}
title @s title [{"text":""},{"text":"  ","color":"#ff3b3b","bold":true,"obfuscated":true},{"storage":"nexora:config","nbt":"alerts.system_error.title","color":"#ff3b3b","bold":true,"obfuscated":true}]
