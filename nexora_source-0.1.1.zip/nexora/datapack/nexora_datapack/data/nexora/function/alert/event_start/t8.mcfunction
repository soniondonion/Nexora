execute as @a[tag=nx_a_event_start] at @s run function nexora:alert/event_start/p8
schedule function nexora:alert/event_start/t24 16t
