# NEXORA ALERT #7 Ubicación localizada (definition v1.0.0)
# Do not edit: generated from alerts/definitions/07_location_found.json.
scoreboard players operation location_found nexora.rep = location_found nexora.repcfg
function nexora:alert/location_found/t0
