scoreboard players set #r nexora.tmp 0
execute if score anomaly_detected nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/anomaly_detected/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_anomaly_detected] remove nx_a_anomaly_detected
