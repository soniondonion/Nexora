execute as @a[tag=nx_a_player_eliminated] at @s run function nexora:alert/player_eliminated/p12
schedule function nexora:alert/player_eliminated/t16 4t
