execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p44
schedule function nexora:alert/zeryth_moment/t46 2t
