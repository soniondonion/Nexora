execute if score system_error nexora.snd matches 1 run playsound minecraft:block.dispenser.fail master @s ~ ~ ~ 0.9 0.6
