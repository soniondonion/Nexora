execute if score personal_notification nexora.snd matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.3 1.8
execute if score personal_notification nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:0.8f} ^1.4 ^0.9 ^2.5 0.05 0.05 0.05 0 4 force @s
title @s actionbar [{"text":""},{"text":"◆ ","color":"#39ff88"},{"storage":"nexora:config","nbt":"alerts.personal_notification.title","color":"#8a8f8c"}]
