title @s times 4 32 4
title @s subtitle {"storage":"nexora:config","nbt":"alerts.gulag_results.p2_sub","color":"#8a8f8c"}
title @s title [{"text":""},{"storage":"nexora:config","nbt":"alerts.gulag_results.p2_label","bold":true,"color":"#c9d1d3"},{"text":" ","bold":true},{"selector":"@a[tag=nx_rank2,limit=1]","bold":true,"color":"#ffffff"}]
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.285 ^0.093 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.243 ^0.176 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.176 ^0.243 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.093 ^0.285 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0 ^0.3 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.093 ^0.285 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.176 ^0.243 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.243 ^0.176 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.285 ^0.093 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.3 ^0 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.285 ^-0.093 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.243 ^-0.176 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.176 ^-0.243 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^-0.093 ^-0.285 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0 ^-0.3 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.093 ^-0.285 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.176 ^-0.243 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.243 ^-0.176 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.788f,0.82f,0.827f],scale:1.3f} ^0.285 ^-0.093 ^3 0 0 0 0 1 force @s
execute if score gulag_results nexora.snd matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.05
execute if score gulag_results nexora.snd matches 1 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.1
