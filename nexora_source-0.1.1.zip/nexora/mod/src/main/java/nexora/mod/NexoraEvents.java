package nexora.mod;

import java.io.IOException;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.GameType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import nexora.core.AuditLog;
import nexora.core.GulagSystem;
import nexora.core.NexoraConstants;
import nexora.core.PlayerState;

/** Event wiring. UNCOMPILED: see Nexora for the verification note. */
@EventBusSubscriber(modid = Nexora.MODID)
public final class NexoraEvents {

    private NexoraEvents() {
    }

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent event) {
        Nexora.start(event.getServer());
        BanSync.reconcile(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        Datapack.announceMod(event.getServer());
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            // Minigames are independent from hardcore elimination: a participant "defeated" in a minigame
            // never really dies. The tag is only ever set by the admin-gated minigame/start function.
            if (p.getTags().contains("nx_mg_active")) {
                event.setCanceled(true);
                p.setHealth(p.getMaxHealth());
                p.getFoodData().setFoodLevel(20);
                p.removeAllEffects();
                p.clearFire();
                Datapack.runAs(p.server, p.getUUID(), "function nexora:internal/minigame_defeat");
                Nexora.audit.log(AuditLog.Stream.AUTOMATIC, "minigame_death_prevented",
                        java.util.Map.of("uuid", p.getUUID().toString()));
                return;
            }
            DeathFlow.onDeath(p, event.getSource());
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            DeathFlow.onRespawn(p);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p) || !Nexora.ready()) {
            return;
        }
        MinecraftServer server = p.server;
        PlayerState state = Nexora.deaths.stateOf(p.getUUID());
        boolean exemptAdmin = Nexora.config.adminsExemptFromElimination && NexoraPermissions.isAdmin(p);

        if (!exemptAdmin) {
            switch (state) {
                case ELIMINATED -> {
                    // Fallback for a hand-made /pardon: the ban list should have stopped them already.
                    BanSync.reconcile(server);
                    Nexora.audit.log(AuditLog.Stream.AUTOMATIC, "blocked_login",
                            java.util.Map.of("uuid", p.getUUID().toString(), "state", state.name()));
                    p.connection.disconnect(Component.literal(NexoraConstants.DEATH_MESSAGE));
                    return;
                }
                case GULAG -> {
                    GulagSystem.Status gs = Nexora.gulag.status();
                    if (gs != GulagSystem.Status.OPEN && gs != GulagSystem.Status.RUNNING) {
                        p.connection.disconnect(Component.literal(NexoraConstants.DEATH_MESSAGE));
                        return;
                    }
                    p.setGameMode(GameType.ADVENTURE); // never in survival while in the gulag
                }
                case RETURN_PENDING -> applyReturn(server, p);
                default -> {
                    // ALIVE / REVIVED: nothing to do
                }
            }
        }
        TeamVisuals.syncPlayer(server, p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p && Nexora.ready()) {
            try {
                Nexora.gulag.onDisconnect(p.getUUID(), null);
            } catch (IOException e) {
                Nexora.LOGGER.error("[NEXORA] gulag disconnect handling failed", e);
            }
            // NOTE: a disconnect never cancels an elimination: the record was written at the moment of death.
        }
    }

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        DeathFlow.tick(server);
        // Cheap periodic maintenance (every 5 s): admin tag / presentation refresh and pending returns.
        if (server.getTickCount() % 100 == 0 && Nexora.ready()) {
            TeamVisuals.syncAll(server);
            applyPendingReturns(server);
        }
    }

    // ------------------------------------------------------------------ returns

    public static void applyPendingReturns(MinecraftServer server) {
        if (!Nexora.ready()) {
            return;
        }
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (Nexora.deaths.stateOf(p.getUUID()) == PlayerState.RETURN_PENDING) {
                applyReturn(server, p);
            }
        }
    }

    /** RETURN_PENDING -> REVIVED: main spawn, clean slate, survival. Idempotent via the state machine. */
    public static void applyReturn(MinecraftServer server, ServerPlayer p) {
        try {
            ServerLevel overworld = server.overworld();
            BlockPos spawn = overworld.getSharedSpawnPos();
            if (Nexora.config.reviveClearInventory) {
                p.getInventory().clearContent(); // prevents duplication of items already dropped at death
            }
            p.removeAllEffects();
            p.setHealth(p.getMaxHealth());
            p.getFoodData().setFoodLevel(20);
            p.fallDistance = 0;
            p.setGameMode(GameType.SURVIVAL);
            p.teleportTo(overworld, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, 0.0F, 0.0F);
            Nexora.deaths.markRevived(p.getUUID());
            BanSync.reconcile(server);
            DeathFlow.forget(p.getUUID());
            Datapack.alert(server, "player_restored", "@a[name=" + p.getGameProfile().getName() + "]");
        } catch (IOException e) {
            Nexora.LOGGER.error("[NEXORA] could not persist revival of {}", p.getUUID(), e);
        }
    }
}
