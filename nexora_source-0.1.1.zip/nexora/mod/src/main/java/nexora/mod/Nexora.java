package nexora.mod;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.util.Map;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.fml.loading.FMLPaths;

import com.mojang.logging.LogUtils;
import nexora.core.AtomicStore;
import nexora.core.AuditLog;
import nexora.core.DeathSystem;
import nexora.core.GulagSystem;
import nexora.core.NexoraConfig;
import nexora.core.TeamSystem;
import nexora.core.json.Json;
import org.slf4j.Logger;

/**
 * Service holder. Everything here is server-side only and is (re)built on every server start.
 *
 * UNCOMPILED: this class and the rest of nexora.mod could not be built in the authoring sandbox.
 * The Minecraft-independent logic in nexora.core is compiled and unit-tested.
 */
public final class Nexora {

    public static final String MODID = "nexora";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static volatile boolean ready;
    public static MinecraftServer server;
    public static NexoraConfig config;
    public static AuditLog audit;
    public static DeathSystem deaths;
    public static TeamSystem teams;
    public static GulagSystem gulag;
    public static AuthBridge auth = new AuthBridge.AlwaysAuthenticated();

    private Nexora() {
    }

    public static void start(MinecraftServer s) {
        ready = false;
        server = s;
        try {
            Path cfgDir = FMLPaths.CONFIGDIR.get().resolve("nexora");
            Files.createDirectories(cfgDir);
            Path cfgFile = cfgDir.resolve("config.json");
            config = loadConfig(cfgFile);

            Path data = s.getWorldPath(LevelResource.ROOT).resolve("nexora");
            Files.createDirectories(data);
            Clock clock = Clock.systemUTC();
            audit = new AuditLog(data.resolve("logs"), clock);

            deaths = new DeathSystem(data.resolve("players.json"), clock, audit);
            deaths.load();
            teams = new TeamSystem(data.resolve("teams.json"), clock, audit, config);
            teams.load();
            gulag = new GulagSystem(data.resolve("gulag.json"), config, deaths, audit);
            gulag.load();

            ready = true;
            audit.log(AuditLog.Stream.AUTOMATIC, "server_started", Map.of("modVersion", "0.1.0"));
            LOGGER.info("[NEXORA] started. {} team(s), {} player record(s).", teams.all().size(), deaths.all().size());
        } catch (Exception e) {
            // Fail CLOSED: with no trustworthy state the mod refuses to operate and says so loudly.
            LOGGER.error("[NEXORA] FAILED TO LOAD STATE. Elimination and admin features are DISABLED until fixed.", e);
        }
    }

    public static void reloadConfig() throws IOException {
        Path cfgFile = FMLPaths.CONFIGDIR.get().resolve("nexora").resolve("config.json");
        NexoraConfig fresh = loadConfig(cfgFile);
        // The core systems hold a reference to the config object, so copy values in place.
        config.adminMinOpLevel = fresh.adminMinOpLevel;
        config.adminsExemptFromElimination = fresh.adminsExemptFromElimination;
        config.allowAdminsWithoutAuthInOfflineMode = fresh.allowAdminsWithoutAuthInOfflineMode;
        config.deathKickDelayTicks = fresh.deathKickDelayTicks;
        config.reviveClearInventory = fresh.reviveClearInventory;
        config.teamRequestTtlSeconds = fresh.teamRequestTtlSeconds;
        config.teamMaxMembers = fresh.teamMaxMembers;
        config.gulagPlacementPoints = fresh.gulagPlacementPoints;
        config.gulagCompletionPoints = fresh.gulagCompletionPoints;
        config.gulagNotCompletedPoints = fresh.gulagNotCompletedPoints;
        config.gulagCompletionStacks = fresh.gulagCompletionStacks;
        config.gulagDisconnectPolicy = fresh.gulagDisconnectPolicy;
        config.gulagTiebreakers = fresh.gulagTiebreakers;
        config.gulagCutoffTiePolicy = fresh.gulagCutoffTiePolicy;
        config.gulagAllowLateRegistration = fresh.gulagAllowLateRegistration;
        // team name length and forbidden colors are intentionally NOT hot-reloaded: they feed objects built at start.
    }

    private static NexoraConfig loadConfig(Path file) throws IOException {
        if (!Files.exists(file)) {
            NexoraConfig def = new NexoraConfig();
            AtomicStore.write(file, Json.write(def.toMap()));
            return def;
        }
        return NexoraConfig.fromMap(Json.asObject(Json.parse(Files.readString(file))));
    }

    public static boolean ready() {
        return ready && deaths != null && teams != null && gulag != null;
    }
}
