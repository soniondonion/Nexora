function nexora:alert/dimensional_rift/end
