# Macro: id, value (0 = no particles, 1..3).
execute if entity @s[type=player,tag=!nexora_admin] run return fail
$scoreboard players set $(id) nexora.int $(value)
