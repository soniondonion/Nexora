execute if entity @s[type=player,tag=!nexora_admin] run return fail
$data remove storage nexora:zones list[{id:"$(id)"}]
tellraw @a[tag=nexora_admin] [{"text":"[NEXORA] ","color":"green"},{"text":"Zona eliminada.","color":"gray"}]
