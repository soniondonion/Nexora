execute as @a[tag=nx_a_zeryth_moment] at @s run function nexora:alert/zeryth_moment/p4
schedule function nexora:alert/zeryth_moment/t6 2t
