execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.042 ^-0.511 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.39 ^0.356 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.352 ^-0.074 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.166 ^0.464 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.457 ^-0.164 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.337 ^0.266 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.368 ^0.366 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.359 ^-0.349 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.226 ^0.397 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.259 ^0.424 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^0.479 ^0.119 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.int matches 1.. anchored eyes run particle minecraft:dust{color:[0.224f,1f,0.533f],scale:1.0f} ^-0.404 ^-0.006 ^3 0 0 0 0 1 force @s
execute if score zeryth_moment nexora.snd matches 1 run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 0.35 0.5
