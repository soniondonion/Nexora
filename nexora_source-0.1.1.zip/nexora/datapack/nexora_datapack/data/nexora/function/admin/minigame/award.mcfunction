# Macro: id, player (name), points.
execute if entity @s[type=player,tag=!nexora_admin] run return fail
$scoreboard players add $(player) nx_mg_$(id) $(points)
