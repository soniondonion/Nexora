execute as @a[tag=nx_a_anomaly_detected] at @s run function nexora:alert/anomaly_detected/p12
schedule function nexora:alert/anomaly_detected/t15 3t
