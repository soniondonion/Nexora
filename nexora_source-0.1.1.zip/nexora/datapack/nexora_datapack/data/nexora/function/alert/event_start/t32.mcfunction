execute as @a[tag=nx_a_event_start] at @s run function nexora:alert/event_start/p32
schedule function nexora:alert/event_start/t48 16t
