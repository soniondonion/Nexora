package nexora.mod;

import net.minecraft.server.level.ServerPlayer;

/**
 * Seam for the login mod the owner will install (name not known yet).
 *
 * Authentication and authorization are independent: a logged-in player is NOT an admin.
 * {@link NexoraPermissions#isAdmin} requires BOTH (a) the permission node resolving to true and
 * (b) {@link #isAuthenticated} returning true.
 *
 * PENDING COMPATIBILITY: write one implementation per supported login mod once its name is known
 * and assign it to {@link Nexora#auth}. Until then the default trusts the connection (correct for
 * online-mode servers, where Mojang already authenticated the UUID, and NOT sufficient for offline-mode).
 */
public interface AuthBridge {

    boolean isAuthenticated(ServerPlayer player);

    final class AlwaysAuthenticated implements AuthBridge {
        @Override
        public boolean isAuthenticated(ServerPlayer player) {
            return true;
        }
    }
}
