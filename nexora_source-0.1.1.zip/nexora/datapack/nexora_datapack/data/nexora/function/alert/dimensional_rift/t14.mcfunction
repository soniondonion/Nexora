execute as @a[tag=nx_a_dimensional_rift] at @s run function nexora:alert/dimensional_rift/p14
schedule function nexora:alert/dimensional_rift/t16 2t
