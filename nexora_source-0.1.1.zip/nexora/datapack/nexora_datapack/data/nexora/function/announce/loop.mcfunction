execute unless data storage nexora:tmp aq[0] run return 0
execute store result score #due nexora.tmp run data get storage nexora:tmp aq[0].due
execute if score #due nexora.tmp <= #now nexora.tmp run function nexora:announce/fire with storage nexora:tmp aq[0]
execute if score #due nexora.tmp > #now nexora.tmp run data modify storage nexora:announce queue append from storage nexora:tmp aq[0]
data remove storage nexora:tmp aq[0]
function nexora:announce/loop
