scoreboard players set #r nexora.tmp 0
execute if score dimensional_rift nexora.rep matches 1.. run scoreboard players set #r nexora.tmp 1
execute if score #r nexora.tmp matches 1 run function nexora:alert/dimensional_rift/repeat
execute if score #r nexora.tmp matches 0 run tag @a[tag=nx_a_dimensional_rift] remove nx_a_dimensional_rift
